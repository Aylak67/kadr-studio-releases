@echo off
taskkill /im "Kadr Studio.exe" /f >nul 2>&1
rmdir /s /q "%LOCALAPPDATA%\Programs\Kadr Studio"
rmdir /s /q "%APPDATA%\Kadr Studio\versions"
powershell -NoProfile -Command "Remove-Item -ErrorAction SilentlyContinue (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Kadr Studio.lnk'), (Join-Path ([Environment]::GetFolderPath('Programs')) 'Kadr Studio.lnk')"
echo Kadr Studio udalena. Proekty ostalis v papke %USERPROFILE%\.kadr
timeout /t 3 >nul
