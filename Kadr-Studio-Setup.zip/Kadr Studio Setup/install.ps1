$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ver  = '44.9.2'
$dest = Join-Path $env:LOCALAPPDATA 'Programs\Kadr Studio'
$tmp  = Join-Path $env:TEMP ("kadr-engine-" + $ver + ".zip")
$file = "electron-v$ver-win32-x64.zip"
$urls = @(
  "https://github.com/electron/electron/releases/download/v$ver/$file",
  "https://cdn.npmmirror.com/binaries/electron/v$ver/$file",
  "https://registry.npmmirror.com/-/binary/electron/v$ver/$file"
)

Write-Host ''
Write-Host '  Kadr Studio 0.2.1 - ustanovka' -ForegroundColor Magenta
Write-Host ''
Get-Process 'Kadr Studio' -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 500
$engineMark = Join-Path $dest 'engine.txt'
$haveEngine = (Test-Path (Join-Path $dest 'Kadr Studio.exe')) -and (Test-Path $engineMark) -and ((Get-Content $engineMark -Raw).Trim() -eq $ver)

function Test-Engine($p) { (Test-Path $p) -and ((Get-Item $p).Length -gt 60MB) }

if ($haveEngine) {
  Write-Host 'Dvizhok uzhe ustanovlen - obnovlyayu tolko programmu.' -ForegroundColor Cyan
} else {
  if (-not (Test-Engine $tmp)) {
    $ok = $false
    foreach ($u in $urls) {
      Write-Host "Skachivayu dvizhok programmy (~160 MB)..." -ForegroundColor Cyan
      Write-Host "  $u"
      try {
        if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
          & curl.exe -L --fail --retry 3 -o $tmp $u
        } else {
          Invoke-WebRequest -Uri $u -OutFile $tmp -UseBasicParsing
        }
        if (Test-Engine $tmp) { $ok = $true; break }
      } catch { Write-Host ("  ne poluchilos: " + $_.Exception.Message) -ForegroundColor Yellow }
    }
    if (-not $ok) { throw 'Ne udalos skachat dvizhok. Proverte internet i zapustite ustanovku eshche raz.' }
  }

  Write-Host 'Raspakovyvayu...' -ForegroundColor Cyan
  if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
  New-Item -ItemType Directory -Path $dest -Force | Out-Null
  if (Get-Command tar.exe -ErrorAction SilentlyContinue) {
    & tar.exe -xf $tmp -C $dest
  } else {
    Expand-Archive -Path $tmp -DestinationPath $dest -Force
  }
  if (-not (Test-Path (Join-Path $dest 'electron.exe'))) { throw 'Arhiv dvizhka povrezhden. Udalite fail ' + $tmp + ' i zapustite ustanovku eshche raz.' }
  Rename-Item (Join-Path $dest 'electron.exe') 'Kadr Studio.exe'
  Set-Content -Path $engineMark -Value $ver
}

Remove-Item (Join-Path $dest 'resources\default_app.asar') -Force -ErrorAction SilentlyContinue
$appDir = Join-Path $dest 'resources\app'
if (Test-Path $appDir) { Remove-Item $appDir -Recurse -Force }
Copy-Item (Join-Path $PSScriptRoot 'app') $appDir -Recurse -Force
Copy-Item (Join-Path $PSScriptRoot 'kadr.ico') (Join-Path $dest 'kadr.ico') -Force

$exe = Join-Path $dest 'Kadr Studio.exe'
$ico = Join-Path $dest 'kadr.ico'
$w = New-Object -ComObject WScript.Shell
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $l = $w.CreateShortcut((Join-Path $dir 'Kadr Studio.lnk'))
  $l.TargetPath = $exe
  $l.WorkingDirectory = $dest
  $l.IconLocation = $ico
  $l.Description = 'Kadr Studio'
  $l.Save()
}

Write-Host ''
Write-Host 'Gotovo! Znachok "Kadr Studio" poyavilsya na rabochem stole i v menyu Pusk.' -ForegroundColor Green
Start-Process $exe
