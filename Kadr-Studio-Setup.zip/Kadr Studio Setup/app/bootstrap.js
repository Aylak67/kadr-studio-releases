// Kadr Studio bootstrap — installed once, never changes.
// Picks the newest installed app core (from %APPDATA%/Kadr Studio/versions or the bundled core.tgz) and starts it.
const { app, dialog } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');

app.setName('Kadr Studio');

/** Compares "1.2.3" versions. */
function cmp(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
  return 0;
}

/** Minimal .tar.gz reader (ustar + GNU long names + pax path). Returns [{name, data}] for files. */
function untgz(buf) {
  const tar = zlib.gunzipSync(buf);
  const out = [];
  const cstr = (b, s, l) => {
    const e = b.indexOf(0, s);
    return b.toString('utf8', s, e < 0 || e > s + l ? s + l : e);
  };
  let off = 0;
  let longName = null;
  while (off + 512 <= tar.length) {
    const h = tar.subarray(off, off + 512);
    if (h.every((x) => x === 0)) break;
    const size = parseInt(cstr(h, 124, 12).trim() || '0', 8);
    const type = String.fromCharCode(h[156] || 48);
    let name = cstr(h, 0, 100);
    const prefix = cstr(h, 257, 6).startsWith('ustar') ? cstr(h, 345, 155) : '';
    if (prefix) name = prefix + '/' + name;
    const data = tar.subarray(off + 512, off + 512 + size);
    off += 512 + Math.ceil(size / 512) * 512;
    if (type === 'L') {
      longName = data.toString('utf8').replace(/\0.*$/s, '');
      continue;
    }
    if (type === 'x') {
      const m = /\d+ path=([^\n]*)\n/.exec(data.toString('utf8'));
      if (m) longName = m[1];
      continue;
    }
    if (longName) name = longName;
    longName = null;
    if (type === '0' || type === '\0' || type === '7') out.push({ name, data: Buffer.from(data) });
  }
  return out;
}

/** Extracts a core .tgz into versionsDir/<version>; returns {version, dir}. */
function installCore(tgz, versionsDir) {
  const files = untgz(tgz);
  const vf = files.find((f) => f.name.replace(/^\.\//, '') === 'version.json');
  if (!vf) throw new Error('core archive has no version.json');
  const version = JSON.parse(vf.data.toString('utf8')).version;
  const dir = path.join(versionsDir, version);
  const tmp = dir + '.tmp-' + process.pid;
  fs.rmSync(tmp, { recursive: true, force: true });
  for (const f of files) {
    const rel = f.name.replace(/^\.\//, '');
    if (!rel || rel.split(/[\\/]/).includes('..') || path.isAbsolute(rel)) continue;
    const target = path.join(tmp, rel);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, f.data);
  }
  fs.rmSync(dir, { recursive: true, force: true });
  fs.renameSync(tmp, dir);
  fs.writeFileSync(path.join(versionsDir, 'current.json'), JSON.stringify({ version, installedAt: new Date().toISOString() }));
  // keep at most 3 versions
  const all = fs.readdirSync(versionsDir).filter((d) => /^\d+\.\d+\.\d+$/.test(d)).sort(cmp);
  for (const old of all.slice(0, Math.max(0, all.length - 3))) if (old !== version) fs.rmSync(path.join(versionsDir, old), { recursive: true, force: true });
  return { version, dir };
}

function main() {
  const versionsDir = path.join(app.getPath('userData'), 'versions');
  fs.mkdirSync(versionsDir, { recursive: true });
  let current = null;
  try {
    const c = JSON.parse(fs.readFileSync(path.join(versionsDir, 'current.json'), 'utf8'));
    const dir = path.join(versionsDir, c.version);
    if (fs.existsSync(path.join(dir, 'shell.js'))) current = { version: c.version, dir };
  } catch {
    /* first run */
  }
  // a newer core shipped with the installer wins over an older downloaded one
  const bundled = path.join(__dirname, 'core.tgz');
  if (fs.existsSync(bundled)) {
    try {
      const buf = fs.readFileSync(bundled);
      const peek = untgz(buf).find((f) => f.name.replace(/^\.\//, '') === 'version.json');
      const bv = peek ? JSON.parse(peek.data.toString('utf8')).version : '0.0.0';
      if (!current || cmp(bv, current.version) > 0) current = installCore(buf, versionsDir);
    } catch (e) {
      if (!current) throw e;
    }
  }
  if (!current) throw new Error('Kadr Studio core is not installed. Please run the installer again.');
  require(path.join(current.dir, 'shell.js')).start({ coreDir: current.dir, version: current.version, versionsDir, bootstrapDir: __dirname, installCore, cmp });
}

try {
  main();
} catch (e) {
  app.whenReady().then(() => {
    dialog.showErrorBox('Kadr Studio', String((e && e.stack) || e));
    app.quit();
  });
}
