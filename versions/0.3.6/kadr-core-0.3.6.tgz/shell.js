// Kinora app core (updatable). Started by bootstrap.js from %APPDATA%/Kadr Studio/versions/<version>/
// (the internal folder keeps its old name so existing installs keep working).
// - runs the local Kinora server (editor + projects + MCP over HTTP) with Electron's built-in Node
// - opens the editor window (live sync with Claude)
// - checks for updates and offers to install them
// - connects Kinora to Claude Desktop / Claude Code (MCP)
const { app, BrowserWindow, Menu, shell, session, dialog, ipcMain, net, Notification } = require('electron');
const { spawn } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const UPDATE_URL = process.env.KADR_UPDATE_URL || 'https://raw.githubusercontent.com/Aylak67/kadr-studio-releases/main/latest.json';
const RELEASES_PAGE = 'https://github.com/Aylak67/kadr-studio-releases';
const PREFERRED_PORT = 7788;

exports.start = function start(ctx) {
  const { coreDir, version, versionsDir, installCore, cmp } = ctx;
  const meta = readJson(path.join(coreDir, 'version.json'), {});
  const userData = app.getPath('userData');
  const statePath = path.join(userData, 'state.json');
  const state = readJson(statePath, {});
  const saveState = () => writeJson(statePath, state);

  if (!app.requestSingleInstanceLock()) {
    app.quit();
    return;
  }

  let win = null;
  let server = null;
  let port = 0;
  let quitting = false;
  let updateBusy = false;

  /* ------------------------------------------------------------ plan / license */
  function plan() {
    const lic = state.license ? verifyLicense(state.license) : null;
    if (lic && lic !== 'free') return lic;
    return meta.defaultPlan || 'free';
  }

  /* ---------------------------------------------------------------- server */
  const serverCli = path.join(coreDir, 'server', 'cli.cjs');
  const logFile = path.join(userData, 'server.log');

  function startServer() {
    return new Promise((resolve) => {
      if (!fs.existsSync(serverCli)) return resolve(0);
      const out = fs.createWriteStream(logFile, { flags: 'w' });
      server = spawn(process.execPath, [serverCli, '--http', '--host', '127.0.0.1', '--port', String(PREFERRED_PORT), '--plan', plan()], {
        env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', KADR_REPORT_PORT: '1', KADR_LOCALE: app.getLocale().startsWith('ru') ? 'ru' : 'en' },
        stdio: ['ignore', 'pipe', 'pipe'],
        windowsHide: true,
      });
      let done = false;
      const finish = (p) => {
        if (done) return;
        done = true;
        resolve(p);
      };
      const onData = (d) => {
        out.write(d);
        const m = /KADR_PORT=(\d+)/.exec(String(d));
        if (m) finish(Number(m[1]));
      };
      server.stdout.on('data', onData);
      server.stderr.on('data', onData);
      server.on('error', () => finish(0));
      server.on('exit', (code) => {
        out.end();
        server = null;
        finish(0);
        if (!quitting && port) console.error('[kadr] server exited', code);
      });
      setTimeout(() => finish(0), 20000);
    });
  }

  function stopServer() {
    if (server) {
      try {
        server.kill();
      } catch {
        /* already gone */
      }
      server = null;
    }
  }

  async function restartServer() {
    stopServer();
    await new Promise((r) => setTimeout(r, 400));
    port = await startServer();
    if (win && port) win.loadURL(`http://127.0.0.1:${port}/`);
  }

  /* ---------------------------------------------------------------- window */
  function createWindow() {
    win = new BrowserWindow({
      width: 1440,
      height: 900,
      minWidth: 960,
      minHeight: 600,
      title: 'Kinora',
      backgroundColor: '#0a0b0e',
      icon: fs.existsSync(path.join(coreDir, 'icon.png')) ? path.join(coreDir, 'icon.png') : path.join(ctx.bootstrapDir, 'icon.png'),
      autoHideMenuBar: true,
      show: false,
      webPreferences: { contextIsolation: true, sandbox: true, spellcheck: false, preload: path.join(coreDir, 'preload.js') },
    });
    win.once('ready-to-show', () => {
      if (state.maximized !== false) win.maximize();
      win.show();
    });
    win.on('close', () => {
      state.maximized = win.isMaximized();
      saveState();
    });
    win.on('closed', () => (win = null));
    if (port) win.loadURL(`http://127.0.0.1:${port}/`);
    else win.loadFile(path.join(coreDir, 'editor', 'index.html'));
    win.webContents.setWindowOpenHandler(({ url }) => {
      if (isOwnUrl(url) && /\/renders\/|\/files\//.test(url)) return { action: 'allow' };
      if (/^https?:/.test(url)) shell.openExternal(url);
      return { action: 'deny' };
    });
    win.webContents.on('will-navigate', (e, url) => {
      if (!isOwnUrl(url)) {
        e.preventDefault();
        if (/^https?:/.test(url)) shell.openExternal(url);
      }
    });
    win.webContents.on('before-input-event', (e, input) => {
      if (input.type !== 'keyDown') return;
      if (input.key === 'F11') win.setFullScreen(!win.isFullScreen());
      if (input.control && input.shift && input.key.toLowerCase() === 'i') win.webContents.toggleDevTools();
      if (input.key === 'F5' || (input.control && input.key.toLowerCase() === 'r')) win.webContents.reload();
    });
    // if the server could not start (or dies), fall back to the offline editor
    win.webContents.on('did-fail-load', (_e, code, _desc, url) => {
      if (code !== -3 && isOwnUrl(url) && url.startsWith('http')) win.loadFile(path.join(coreDir, 'editor', 'index.html'));
    });
  }

  function isOwnUrl(url) {
    return url.startsWith('file:') || (port && url.startsWith(`http://127.0.0.1:${port}/`)) || url.startsWith('devtools:');
  }

  /* --------------------------------------------------------------- updates */
  async function fetchLatest() {
    const r = await net.fetch(`${UPDATE_URL}${UPDATE_URL.includes('?') ? '&' : '?'}t=${Date.now()}`, { cache: 'no-store' });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.json();
  }

  async function download(url, expectedSize, onProgress) {
    const r = await net.fetch(url);
    if (!r.ok || !r.body) throw new Error(`HTTP ${r.status}`);
    const total = Number(r.headers.get('content-length')) || expectedSize || 0;
    const reader = r.body.getReader();
    const chunks = [];
    let got = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(Buffer.from(value));
      got += value.length;
      if (total) onProgress(Math.min(1, got / total));
    }
    return Buffer.concat(chunks);
  }

  /**
   * Checks for a newer version. `manual`: invoked by the user (always report the result).
   * Returns {status: 'latest'|'available'|'installed'|'later'|'error', ...}.
   */
  async function checkUpdates(manual) {
    if (updateBusy) return { status: 'busy' };
    let latest;
    try {
      latest = await fetchLatest();
    } catch (e) {
      if (manual) dialog.showMessageBox(win, { type: 'warning', title: 'Kinora', message: tr('Не удалось проверить обновления', 'Could not check for updates'), detail: String(e.message || e) });
      return { status: 'error', error: String(e.message || e) };
    }
    if (!latest || !latest.version || cmp(latest.version, version) <= 0) {
      if (manual) dialog.showMessageBox(win, { type: 'info', title: 'Kinora', message: tr(`У вас последняя версия (${version})`, `You have the latest version (${version})`) });
      return { status: 'latest', version, latest: latest && latest.version };
    }
    if (!manual && state.skipVersion === latest.version) return { status: 'skipped', latest: latest.version };

    const needsInstaller = latest.minBootstrap && cmp(latest.minBootstrap, readJson(path.join(ctx.bootstrapDir, 'package.json'), {}).version || '1.0.0') > 0;
    const notes = String(latest.notes || '').slice(0, 1500);
    const ask = (opts) => (process.env.KADR_TEST_AUTOACCEPT ? Promise.resolve({ response: 0 }) : dialog.showMessageBox(win, opts));
    const { response } = await ask({
      type: 'info',
      title: tr('Обновление Kinora', 'Kinora update'),
      message: tr(`Доступна новая версия ${latest.version}`, `Version ${latest.version} is available`),
      detail: `${tr('Сейчас установлена', 'Installed')}: ${version}${notes ? `\n\n${tr('Что нового', "What's new")}:\n${notes}` : ''}`,
      buttons: [tr('Обновить сейчас', 'Update now'), tr('Позже', 'Later'), tr('Пропустить эту версию', 'Skip this version')],
      defaultId: 0,
      cancelId: 1,
      noLink: true,
    });
    if (response === 2) {
      state.skipVersion = latest.version;
      saveState();
      return { status: 'later' };
    }
    if (response !== 0) return { status: 'later' };
    if (needsInstaller || !latest.url) {
      shell.openExternal(latest.installerUrl || RELEASES_PAGE);
      return { status: 'later' };
    }

    updateBusy = true;
    try {
      win && win.setProgressBar(0.01);
      const buf = await download(latest.url, latest.size, (p) => win && win.setProgressBar(p));
      if (latest.sha256) {
        const sum = crypto.createHash('sha256').update(buf).digest('hex');
        if (sum !== latest.sha256) throw new Error(tr('Файл обновления повреждён (контрольная сумма не совпала). Попробуйте ещё раз.', 'The update file is corrupted (checksum mismatch). Please try again.'));
      }
      const res = installCore(buf, versionsDir);
      win && win.setProgressBar(-1);
      const { response: r2 } = await ask({
        type: 'info',
        title: 'Kinora',
        message: tr(`Версия ${res.version} установлена`, `Version ${res.version} installed`),
        detail: tr('Перезапустить Kinora сейчас? Проекты сохранены.', 'Restart Kinora now? Your projects are saved.'),
        buttons: [tr('Перезапустить', 'Restart'), tr('Позже', 'Later')],
        defaultId: 0,
        noLink: true,
      });
      if (r2 === 0) {
        quitting = true;
        stopServer();
        app.relaunch();
        app.exit(0);
      }
      return { status: 'installed', version: res.version };
    } catch (e) {
      win && win.setProgressBar(-1);
      dialog.showMessageBox(win, { type: 'error', title: 'Kinora', message: tr('Не удалось обновить', 'Update failed'), detail: String(e.message || e) });
      return { status: 'error', error: String(e.message || e) };
    } finally {
      updateBusy = false;
    }
  }

  /* ------------------------------------------------------------ Claude MCP */
  // A tiny launcher outside the versioned folder, so Claude keeps working after updates.
  const launcher = path.join(userData, 'kadr-mcp.cjs');
  function writeLauncher() {
    const src = `// Kinora MCP server launcher for Claude (auto-generated, do not edit).
// Starts the newest installed Kinora core with Electron's built-in Node (ELECTRON_RUN_AS_NODE=1).
const fs = require('fs');
const path = require('path');
const versions = ${JSON.stringify(versionsDir)};
let v = null;
try { v = JSON.parse(fs.readFileSync(path.join(versions, 'current.json'), 'utf8')).version; } catch (e) {}
if (!v) {
  const all = fs.readdirSync(versions).filter((d) => /^\\d+\\.\\d+\\.\\d+$/.test(d)).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  v = all[all.length - 1];
}
process.argv.splice(2, process.argv.length);
require(path.join(versions, v, 'server', 'cli.cjs'));
`;
    try {
      if (!fs.existsSync(launcher) || fs.readFileSync(launcher, 'utf8') !== src) fs.writeFileSync(launcher, src);
    } catch {
      /* read-only? */
    }
  }

  function mcpEntry() {
    return { command: process.execPath, args: [launcher], env: { ELECTRON_RUN_AS_NODE: '1', KADR_PLAN: plan() } };
  }

  /** All Claude Desktop config locations that exist (classic installer + Microsoft Store build). */
  function claudeDesktopConfigs() {
    const appData = app.getPath('appData');
    const list = [path.join(appData, 'Claude', 'claude_desktop_config.json')];
    if (process.platform === 'win32') {
      const pk = path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), 'Packages');
      try {
        for (const d of fs.readdirSync(pk)) if (/^(Claude|AnthropicPBC\.Claude)/i.test(d)) list.push(path.join(pk, d, 'LocalCache', 'Roaming', 'Claude', 'claude_desktop_config.json'));
      } catch {
        /* no store apps */
      }
    }
    return list;
  }

  function claudeDesktopInstalled() {
    return claudeDesktopConfigs().some((f) => fs.existsSync(path.dirname(f)));
  }

  function claudeDesktopConnected() {
    return claudeDesktopConfigs().some((f) => {
      const c = readJson(f, null);
      const e = c && c.mcpServers && (c.mcpServers.kinora || c.mcpServers.kadr);
      return !!(e && JSON.stringify(e.args || []).includes('kadr-mcp.cjs'));
    });
  }

  function connectClaudeDesktop() {
    writeLauncher();
    const files = claudeDesktopConfigs();
    const targets = files.filter((f) => fs.existsSync(path.dirname(f)));
    if (!targets.length) targets.push(files[0]);
    const written = [];
    for (const f of targets) {
      let cfg = {};
      if (fs.existsSync(f)) {
        const raw = fs.readFileSync(f, 'utf8');
        try {
          cfg = raw.trim() ? JSON.parse(raw) : {};
        } catch {
          return { ok: false, error: tr(`Файл настроек Claude повреждён: ${f}`, `Claude config is not valid JSON: ${f}`) };
        }
        fs.copyFileSync(f, f + '.kadr-backup');
      }
      const servers = { ...(cfg.mcpServers || {}) };
      // renamed: Kadr Studio → Kinora (drop our old entry, keep anything else the user has)
      if (servers.kadr && JSON.stringify(servers.kadr.args || []).includes('kadr-mcp.cjs')) delete servers.kadr;
      servers.kinora = mcpEntry();
      cfg.mcpServers = servers;
      fs.mkdirSync(path.dirname(f), { recursive: true });
      fs.writeFileSync(f, JSON.stringify(cfg, null, 2));
      written.push(f);
    }
    return { ok: true, files: written };
  }

  function claudeCodeCommand() {
    const q = (s) => (process.platform === 'win32' ? `"${s}"` : `'${s}'`);
    return `claude mcp add kinora -s user -e ELECTRON_RUN_AS_NODE=1 -- ${q(process.execPath)} ${q(launcher)}`;
  }

  function info() {
    return {
      desktop: true,
      version,
      channel: meta.channel || 'stable',
      builtAt: meta.builtAt,
      platform: process.platform,
      plan: plan(),
      license: state.license ? state.license.replace(/^(KADR-\w+-).*(.{2})$/, '$1••••$2') : null,
      port,
      mcpHttpUrl: port ? `http://127.0.0.1:${port}/mcp` : null,
      claudeDesktop: { installed: claudeDesktopInstalled(), connected: claudeDesktopConnected() },
      claudeCodeCommand: claudeCodeCommand(),
      claudeCodeHttpCommand: port ? `claude mcp add --transport http kinora http://127.0.0.1:${port}/mcp` : null,
      workspace: path.join(os.homedir(), '.kadr'),
      updateUrl: UPDATE_URL,
      autoUpdate: state.autoUpdate !== false,
    };
  }

  /* -------------------------------------------- Windows shortcuts (rename) */
  // Kadr Studio was renamed to Kinora: replace the old Desktop / Start menu shortcuts once,
  // pointing at the same program with the new icon.
  function brandShortcuts() {
    if (process.platform !== 'win32') return;
    const icon = path.join(userData, 'kinora.ico');
    try {
      fs.copyFileSync(path.join(coreDir, 'kinora.ico'), icon);
    } catch {
      return;
    }
    if (state.brand === 'kinora') return;
    const dirs = [app.getPath('desktop'), path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs')];
    for (const d of dirs) {
      const oldLnk = path.join(d, 'Kadr Studio.lnk');
      const newLnk = path.join(d, 'Kinora.lnk');
      if (!fs.existsSync(oldLnk) && !fs.existsSync(newLnk)) continue;
      try {
        shell.writeShortcutLink(newLnk, fs.existsSync(newLnk) ? 'replace' : 'create', { target: process.execPath, cwd: path.dirname(process.execPath), icon, iconIndex: 0, description: 'Kinora' });
        fs.rmSync(oldLnk, { force: true });
      } catch {
        /* keep the old shortcut */
      }
    }
    state.brand = 'kinora';
    saveState();
  }

  /* ------------------------------------------- Windows: Kinora icon in the .exe */
  // The engine is the stock Electron executable (atom icon in the taskbar). Make a copy with the
  // Kinora icon and name, point the shortcuts at it, and use it from the next start.
  const EXE_ICON_VERSION = 1;
  function brandExe() {
    if (process.platform !== 'win32') return;
    const dir = path.dirname(process.execPath);
    const running = path.basename(process.execPath);
    const target = path.join(dir, 'Kinora.exe');
    const old = path.join(dir, 'Kinora.old.exe');
    try {
      fs.rmSync(old, { force: true });
    } catch {
      /* still in use — next time */
    }
    const stamp = (f) => {
      try {
        const st = fs.statSync(f);
        return `${EXE_ICON_VERSION}:${st.size}:${Math.round(st.mtimeMs)}`;
      } catch {
        return '';
      }
    };
    // already running the branded copy (a reinstall replaces the exe → stamp differs → brand again)
    if (running.toLowerCase() === 'kinora.exe' && state.exeStamp && state.exeStamp === stamp(process.execPath)) return;
    const worker = path.join(coreDir, 'exe-icon.cjs');
    const ico = path.join(coreDir, 'kinora.ico');
    if (!fs.existsSync(worker) || !fs.existsSync(ico)) return;
    const out = path.join(dir, 'Kinora.new.exe');
    const child = spawn(process.execPath, [worker, process.execPath, ico, out], { env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }, stdio: 'ignore', windowsHide: true, detached: false });
    child.on('exit', (code) => {
      if (code !== 0 || !fs.existsSync(out)) return;
      try {
        // a running .exe can be renamed (not overwritten) on Windows
        if (fs.existsSync(target)) fs.renameSync(target, old);
        fs.renameSync(out, target);
      } catch {
        try {
          fs.rmSync(out, { force: true });
        } catch {
          /* ignore */
        }
        return;
      }
      const icon = path.join(userData, 'kinora.ico');
      try {
        fs.copyFileSync(ico, icon);
      } catch {
        /* ignore */
      }
      for (const d of [app.getPath('desktop'), path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs')]) {
        const lnk = path.join(d, 'Kinora.lnk');
        try {
          shell.writeShortcutLink(lnk, fs.existsSync(lnk) ? 'replace' : 'create', { target, cwd: dir, icon: target, iconIndex: 0, description: 'Kinora' });
          fs.rmSync(path.join(d, 'Kadr Studio.lnk'), { force: true });
        } catch {
          /* ignore */
        }
      }
      state.exeStamp = stamp(target);
      state.brand = 'kinora';
      saveState();
    });
  }

  /* ------------------------------------------------------------------- IPC */
  ipcMain.handle('kadr:info', () => info());
  /** Diagnostics: Claude config files, a real MCP handshake with the exact command Claude uses, Claude's logs. */
  async function testMcp() {
    const report = { configs: [], handshake: null, logs: [] };
    for (const f of claudeDesktopConfigs()) {
      const exists = fs.existsSync(f);
      const c = exists ? readJson(f, null) : null;
      report.configs.push({ file: f, exists, valid: !exists || !!c, servers: c && c.mcpServers ? Object.keys(c.mcpServers) : [], kinora: !!(c && c.mcpServers && (c.mcpServers.kinora || c.mcpServers.kadr)) });
    }
    writeLauncher();
    const entry = mcpEntry();
    report.command = [entry.command, ...entry.args].join(' ');
    report.handshake = await new Promise((resolve) => {
      let out = '';
      let err = '';
      let done = false;
      const t0 = Date.now();
      const finish = (r) => {
        if (done) return;
        done = true;
        try {
          child.kill();
        } catch {
          /* gone */
        }
        resolve({ ...r, ms: Date.now() - t0, stderr: err.slice(-1500) });
      };
      const child = spawn(entry.command, entry.args, { env: { ...process.env, ...entry.env }, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
      child.on('error', (e) => finish({ ok: false, error: `cannot start: ${e.message}` }));
      child.on('exit', (code) => finish({ ok: false, error: `server exited (code ${code})` }));
      child.stderr.on('data', (d) => (err += d));
      child.stdout.on('data', (d) => {
        out += d;
        for (const line of out.split('\n')) {
          let msg;
          try {
            msg = JSON.parse(line);
          } catch {
            continue;
          }
          if (msg.id === 1) {
            child.stdin.write(JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }) + '\n');
            child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'tools/list' }) + '\n');
          }
          if (msg.id === 2) finish({ ok: true, tools: (msg.result && msg.result.tools ? msg.result.tools.length : 0), server: 'kinora' });
        }
      });
      child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'kinora-selftest', version: '1' } } }) + '\n');
      setTimeout(() => finish({ ok: false, error: 'no answer in 25 s', stdout: out.slice(0, 500) }), 25000);
    });
    // Claude Desktop logs (classic + Microsoft Store builds)
    for (const f of claudeDesktopConfigs()) {
      const dir = path.join(path.dirname(f), 'logs');
      for (const name of ['mcp-server-kinora.log', 'mcp-server-kadr.log', 'mcp.log']) {
        const lf = path.join(dir, name);
        try {
          const txt = fs.readFileSync(lf, 'utf8');
          const lines = txt.split(/\r?\n/).filter((l) => /kinora|kadr|error|fail/i.test(l)).slice(-25);
          if (lines.length) report.logs.push({ file: lf, lines });
        } catch {
          /* no log */
        }
      }
    }
    return report;
  }
  ipcMain.handle('kadr:test-mcp', () => testMcp());

  ipcMain.handle('kadr:connect-claude-desktop', async () => {
    const r = connectClaudeDesktop();
    if (r.ok) {
      await dialog.showMessageBox(win, {
        type: 'info',
        title: 'Kinora',
        message: tr('Kinora подключена к Claude Desktop ✓', 'Kinora is connected to Claude Desktop ✓'),
        detail: tr(
          'Полностью закройте Claude Desktop (в трее: правый клик → Quit) и откройте снова.\nВ чате появятся инструменты «kinora» — просто попросите Claude сделать видео, например:\n«Сделай рекламу кофейни 9:16 с анимированным текстом».',
          'Fully quit Claude Desktop (tray icon → Quit) and open it again.\nThe "kinora" tools will appear in the chat — just ask Claude to make a video.',
        ),
      });
    }
    return { ...r, info: info() };
  });
  ipcMain.handle('kadr:check-updates', () => checkUpdates(true));
  ipcMain.handle('kadr:set-license', async (_e, key) => {
    const p = key ? verifyLicense(String(key).trim()) : 'free';
    if (key && p === 'free') return { ok: false };
    state.license = key ? String(key).trim().toUpperCase() : undefined;
    saveState();
    // the MCP server and Claude's config get the new plan
    if (claudeDesktopConnected()) connectClaudeDesktop();
    restartServer();
    return { ok: true, plan: plan() };
  });
  ipcMain.handle('kadr:open-external', (_e, url) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    else if (url === 'workspace') shell.openPath(path.join(os.homedir(), '.kadr'));
  });

  /* ------------------------------------------------------------- lifecycle */
  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });

  app.whenReady().then(async () => {
    Menu.setApplicationMenu(null);
    session.defaultSession.on('will-download', (_e, item) => {
      item.setSaveDialogOptions({ title: tr('Сохранить файл', 'Save file'), defaultPath: path.join(app.getPath('videos'), item.getFilename()) });
    });
    writeLauncher();
    brandShortcuts();
    // keep Claude's config pointing at this install (e.g. after the app folder moved)
    try {
      if (claudeDesktopConnected()) connectClaudeDesktop();
    } catch {
      /* ignore */
    }
    port = await startServer();
    createWindow();
    setTimeout(brandExe, 8000);
    if (state.lastVersion && state.lastVersion !== version && Notification.isSupported()) {
      new Notification({ title: 'Kinora', body: tr(`Обновлено до версии ${version}`, `Updated to ${version}`) }).show();
    }
    state.lastVersion = version;
    saveState();
    if (state.autoUpdate !== false) {
      setTimeout(() => checkUpdates(false), 6000);
      setInterval(() => checkUpdates(false), 4 * 60 * 60 * 1000);
    }
  });

  app.on('before-quit', () => {
    quitting = true;
    stopServer();
  });
  app.on('window-all-closed', () => app.quit());
};

/* ------------------------------------------------------------------ helpers */
function tr(ru, en) {
  return app.getLocale().startsWith('ru') || app.getLocale().startsWith('uk') || app.getLocale().startsWith('kk') ? ru : en;
}

function readJson(f, def) {
  try {
    return JSON.parse(fs.readFileSync(f, 'utf8'));
  } catch {
    return def;
  }
}

function writeJson(f, v) {
  try {
    fs.mkdirSync(path.dirname(f), { recursive: true });
    fs.writeFileSync(f, JSON.stringify(v, null, 2));
  } catch {
    /* ignore */
  }
}

// Same algorithm as @kadr/core verifyLicenseKey.
function verifyLicense(key) {
  const m = /^KADR-(PRO|TEAM)-([A-Z0-9]{4})-([A-Z0-9]{4})-([A-Z0-9])$/.exec(String(key).trim().toUpperCase());
  if (!m) return 'free';
  let sum = 0;
  for (const ch of m[2] + m[3]) sum = (sum * 31 + ch.charCodeAt(0)) % 36;
  if (sum.toString(36).toUpperCase() !== m[4]) return 'free';
  return m[1] === 'TEAM' ? 'team' : 'pro';
}
