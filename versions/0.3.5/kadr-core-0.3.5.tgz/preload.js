// Bridge between the editor page and the desktop shell.
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('kadrDesktop', {
  info: () => ipcRenderer.invoke('kadr:info'),
  connectClaudeDesktop: () => ipcRenderer.invoke('kadr:connect-claude-desktop'),
  checkUpdates: () => ipcRenderer.invoke('kadr:check-updates'),
  setLicense: (key) => ipcRenderer.invoke('kadr:set-license', key),
  openExternal: (url) => ipcRenderer.invoke('kadr:open-external', url),
});
