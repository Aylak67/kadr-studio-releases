Kinora 0.3.2 dlya Windows

1. Raspakuyte arhiv: pravoy knopkoy -> "Izvlech vse".
2. V raspakovannoy papke dvazhdy shchelknite "Install Kinora.bat".
   Ustanovshchik skachaet dvizhok programmy (~160 MB, nuzhen internet),
   ustanovit Kinora i sozdast znachok na rabochem stole i v menyu Pusk.
   Esli Windows preduprezhdaet o neizvestnom izdatele: "Podrobnee" -> "Vypolnit v lyubom sluchae".
3. Dalshe prosto zapuskayte programmu znachkom na rabochem stole.

Obnovleniya: kogda vyhodit novaya versiya, programma sama predlozhit obnovitsya
(knopka "Obnovit seychas"). Pereustanavlivat nichego ne nuzhno.

Claude: v programme otkroyte vkladku "II" (AI) -> "Podklyuchit Claude Desktop".
Potom perezapustite Claude Desktop i poprosite: "Sdelay reklamu kofeyni 9:16".

Udalit: "Uninstall Kinora.bat".
