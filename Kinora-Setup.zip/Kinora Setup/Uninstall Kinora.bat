@echo off
taskkill /im "Kinora.exe" /f >nul 2>&1
taskkill /im "Kadr Studio.exe" /f >nul 2>&1
rmdir /s /q "%LOCALAPPDATA%\Programs\Kinora"
rmdir /s /q "%LOCALAPPDATA%\Programs\Kadr Studio"
rmdir /s /q "%APPDATA%\Kadr Studio\versions"
powershell -NoProfile -Command "foreach($d in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))){ Remove-Item -ErrorAction SilentlyContinue (Join-Path $d 'Kinora.lnk'), (Join-Path $d 'Kadr Studio.lnk') }"
echo Kinora udalena. Proekty ostalis v papke %USERPROFILE%\.kadr
timeout /t 3 >nul
