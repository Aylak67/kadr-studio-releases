@echo off
cd /d "%~dp0"
if not exist "%~dp0app\bootstrap.js" (
  echo.
  echo Snachala RASPAKUYTE arhiv: pravoy knopkoy po arhivu - "Izvlech vse",
  echo potom zapustite "Install Kinora.bat" iz raspakovannoy papki.
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  echo Ustanovka ne udalas. Sdelayte skrinshot etogo okna.
  pause
  exit /b 1
)
timeout /t 5 >nul
